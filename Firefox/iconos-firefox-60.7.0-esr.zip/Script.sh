#!/bin/sh
rm /opt/firefox/browser/chrome/icons/default/default16.png
rm /opt/firefox/browser/chrome/icons/default/default32.png
rm /opt/firefox/browser/chrome/icons/default/default48.png
rm /opt/firefox/browser/chrome/icons/default/default64.png
rm /opt/firefox/browser/chrome/icons/default/default128.png
cp default16.png /opt/firefox/browser/chrome/icons/default/
cp default32.png /opt/firefox/browser/chrome/icons/default/
cp default48.png /opt/firefox/browser/chrome/icons/default/
cp default64.png /opt/firefox/browser/chrome/icons/default/
cp default128.png /opt/firefox/browser/chrome/icons/default/
